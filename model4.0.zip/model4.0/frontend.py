from flask import Flask, request, render_template_string
import joblib

app = Flask(__name__)

# Load the model
model_data = joblib.load("final_career_model_with_fallback.pkl")
career_dataset = model_data['final_career_dataset']
match_logic = model_data['match_logic']

# Sample interest list with full 25+ yes/no questions
interest_questions = {
    'medicine': "Do you enjoy learning about the human body and helping sick people?",
    'technology': "Are you interested in how machines and gadgets work?",
    'programming': "Do you like writing or learning code?",
    'helping_others': "Do you like assisting others and making a difference in their lives?",
    'engineering': "Do you enjoy designing or building things?",
    'research': "Do you enjoy exploring new ideas and conducting experiments?",
    'problem_solving': "Do you enjoy solving complex challenges?",
    'education': "Are you passionate about teaching or sharing knowledge?",
    'environment': "Are you concerned about nature and protecting the environment?",
    'innovation': "Do you often think of new and creative ideas?",
    'communication': "Are you good at speaking or writing clearly?",
    'leadership': "Do you often find yourself leading or organizing group tasks?",
    'business': "Are you interested in running or managing a business?",
    'healthcare': "Are you drawn to medical or health-related fields?",
    'creativity': "Do you enjoy activities like art, music, or writing?",
    'law': "Are you interested in justice, rules, or debating?",
    'finance': "Do you enjoy working with numbers and money?",
    'public_speaking': "Are you comfortable speaking in front of a crowd?",
    'marketing': "Do you like promoting ideas or products?",
    'data_analysis': "Do you enjoy interpreting data or statistics?",
    'design': "Do you enjoy creating visual designs or graphics?",
    'social_work': "Do you want to help communities and social groups?",
    'sports': "Are you active in sports or fitness activities?",
    'writing': "Do you enjoy writing stories, articles, or blogs?",
    'psychology': "Are you curious about how the human mind works?"
}

# HTML Template
HTML_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>Career Matcher</title>
</head>
<body>
    <h2>Career Recommendation</h2>
    <form method="post">
        <label>Enter your A Level  (comma separated):</label><br>
        <input type="text" name="subjects" style="width: 400px;"><br><br>
        <h4>Answer the following questions (Yes or No):</h4>
        {% for key, question in interests.items() %}
            <label>{{ question }}</label><br>
            <input type="radio" name="{{ key }}" value="1"> Yes
            <input type="radio" name="{{ key }}" value="0"> No<br><br>
        {% endfor %}
        <br>
        <input type="submit" value="Get Career Matches">
    </form>

    {% if results %}
        <h3>Results:</h3>
        {% if results.fallback %}
            <p><strong>No exact matches found due to academic subject mismatch.</strong></p>
            <p>Interests: {{ results.topics }}</p>
            <p>Subjects: {{ results.academic_subjects }}</p>
        {% else %}
            <ul>
                {% for job in results.matches %}
                    <li><strong>{{ job.career_name }}</strong> | Sector: {{ job.sector }}, Salary: {{ job.salary_range }}, Employment: {{ job.employment_rate }}%</li>
                {% endfor %}
            </ul>
        {% endif %}
    {% endif %}
</body>
</html>
"""

@app.route('/', methods=['GET', 'POST'])
def match():
    results = None
    if request.method == 'POST':
        subjects = request.form['subjects'].split(',')
        subjects = [s.strip().title() for s in subjects]
        interest_input = {k: int(request.form.get(k, '0')) for k in interest_questions.keys()}
        results = match_logic(interest_input, subjects, career_dataset)

    return render_template_string(HTML_TEMPLATE, interests=interest_questions, results=results)

if __name__ == '__main__':
    app.run(debug=True)
