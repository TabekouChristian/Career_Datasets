from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
import joblib
from pydantic import BaseModel
from typing import List, Dict

# Define fallback function first (needed for unpickling)
def match_careers_with_fallback(student_subjects, interest_scores, career_subjects_map, interest_vectors):
    matching_careers = []
    for career, required_subjects in career_subjects_map.items():
        if all(sub in student_subjects for sub in required_subjects):
            matching_careers.append(career)

    if matching_careers:
        return matching_careers
    else:
        # fallback: return careers with at least 40% interest match
        fallback_matches = []
        for career, interests in interest_vectors.items():
            score = sum(1 for q in interests if interest_scores.get(q, False))
            match_percentage = score / len(interests)
            if match_percentage >= 0.4:
                fallback_matches.append(career)
        return fallback_matches

# Load the model
model_data = joblib.load("final_career_model_with_fallback.pkl")

# FastAPI app
app = FastAPI()

# Enable CORS (allow frontend access)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Request input format
class RecommendationInput(BaseModel):
    subjects: List[str]
    interest_answers: Dict[str, bool]  # e.g., {"q1": True, "q2": False, ...}

@app.post("/recommend-careers")
def recommend_careers(input_data: RecommendationInput):
    subjects = input_data.subjects
    interest_answers = input_data.interest_answers

    matched = match_careers_with_fallback(
        student_subjects=subjects,
        interest_scores=interest_answers,
        career_subjects_map=model_data["career_subjects"],
        interest_vectors=model_data["interest_vectors"]
    )

    return {"matched_careers": matched}
