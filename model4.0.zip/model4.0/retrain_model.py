import pandas as pd
import pickle
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder

# Load the dataset
df = pd.read_csv("final_career_dataset.csv")

# Encode the target 'career' column
le_career = LabelEncoder()
df["Career_Label"] = le_career.fit_transform(df["career"])

# Save career label encoder
with open("career_label_encoder.pki", "wb") as f:
    pickle.dump(le_career, f)

# Encode categorical features with LabelEncoder
encoders = {}
text_columns = ["required_subjects", "mapped_interest_career", "mapped_employment_career", "sector"]
for col in text_columns:
    le = LabelEncoder()
    df[col] = le.fit_transform(df[col].astype(str))
    encoders[col] = le
    # Save each encoder
    with open(f"{col}_encoder.pki", "wb") as f:
        pickle.dump(le, f)

# Features and target
feature_cols = text_columns + ["estimated_employment_rate"]
X = df[feature_cols]
y = df["Career_Label"]

# Split and train
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
model = DecisionTreeClassifier(max_depth=10, random_state=42)
model.fit(X_train, y_train)

# Save model
with open("final_career_cluster_model.pki", "wb") as f:
    pickle.dump(model, f)

print("✅ Model trained and saved with consistent encoding.")
