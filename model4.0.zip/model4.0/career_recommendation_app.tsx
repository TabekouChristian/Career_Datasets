import React, { useState, useEffect } from 'react';
import * as tf from 'tensorflow';
import Papa from 'papaparse';
import * as d3 from 'd3';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Loader2, CheckCircle, XCircle, BookOpen, Award, Briefcase, TrendingUp } from 'lucide-react';

// Main application component
export default function CareerRecommendationAI() {
  // State variables
  const [isLoading, setIsLoading] = useState(true);
  const [currentStep, setCurrentStep] = useState(0);
  const [isModelTrained, setIsModelTrained] = useState(false);
  const [interestAnswers, setInterestAnswers] = useState({});
  const [selectedSubjects, setSelectedSubjects] = useState([]);
  const [recommendedCareers, setRecommendedCareers] = useState([]);
  const [trainingProgress, setTrainingProgress] = useState(0);
  const [model, setModel] = useState(null);
  const [careerData, setCareerData] = useState([]);
  const [interestQuestions, setInterestQuestions] = useState([]);
  const [allSubjects, setAllSubjects] = useState([]);

  // Initialize and load data
  useEffect(() => {
    const loadData = async () => {
      try {
        // Parse CSV data
        const careerRequirementsText = await window.fs.readFile('career_subject_requirements.csv', { encoding: 'utf8' });
        const finalCareerDatasetText = await window.fs.readFile('final_career_dataset_enhanced.csv', { encoding: 'utf8' });
        const interestQuestionsText = await window.fs.readFile('umbrella_interest_questions_mapping.csv', { encoding: 'utf8' });
        
        // Parse the CSV data
        const careerRequirements = Papa.parse(careerRequirementsText, { header: true, skipEmptyLines: true }).data;
        const finalCareerDataset = Papa.parse(finalCareerDatasetText, { header: true, skipEmptyLines: true }).data;
        const questionsData = Papa.parse(interestQuestionsText, { header: true, skipEmptyLines: true }).data;
        
        // Extract unique subjects from requirements
        const subjectsSet = new Set();
        careerRequirements.forEach(career => {
          if (career.required_subjects) {
            const subjects = career.required_subjects.split(',').map(s => s.trim());
            subjects.forEach(subject => subjectsSet.add(subject));
          }
        });
        
        // Add the additional subjects you mentioned
        const additionalSubjects = [
          "English Language", "French", "General Paper", "Religious Studies", 
          "Philosophy", "Logic", "Food Science & Nutrition", "Agricultural Science", 
          "Physical Education", "Environmental Management", "Literature in English", 
          "Education", "Business Mathematics", "Management", "Law"
        ];
        
        additionalSubjects.forEach(subject => subjectsSet.add(subject));
        
        // Organize subjects by category
        const subjectsByCategory = {
          "Languages & General": ["English Language", "French", "General Paper", "Religious Studies", "Philosophy", "Logic"],
          "Science & Technical": [
            "Mathematics", "Further Mathematics", "Physics", "Chemistry", "Biology", 
            "Computer Science", "ICT", "Geology", "Technical Drawing", 
            "Food Science & Nutrition", "Agricultural Science", "Physical Education", 
            "Environmental Management"
          ],
          "Arts & Humanities": ["History", "Geography", "Literature in English", "Education", "Art", "Music"],
          "Commercial (Business-Oriented)": [
            "Economics", "Accounting", "Business Mathematics", "Management", 
            "Law", "Commerce", "Business", "Entrepreneurship"
          ]
        };
        
        // Format questions data
        const formattedQuestions = questionsData.map(q => ({
          id: parseInt(q.question_id),
          question: q.interest_question,
          options: JSON.parse(q.career_options.replace(/'/g, '"'))
        }));
        
        // Sort questions by ID
        formattedQuestions.sort((a, b) => a.id - b.id);
        
        setCareerData([...finalCareerDataset]);
        setInterestQuestions(formattedQuestions);
        setAllSubjects(subjectsByCategory);
        
        // Preprocess data for model training
        await trainModel(finalCareerDataset, formattedQuestions, Array.from(subjectsSet));
        
        setIsLoading(false);
      } catch (error) {
        console.error("Error loading data:", error);
        setIsLoading(false);
      }
    };

    loadData();
  }, []);

  // Train the model using the processed data
  const trainModel = async (careerDataset, questions, subjects) => {
    try {
      // Create a simple feature mapping
      // This is a simplified approach - in a real implementation, we'd use more sophisticated techniques
      
      // Extract features: interests (30 binary features) + subjects (variable number)
      const NUM_INTEREST_FEATURES = 30;
      const NUM_SUBJECT_FEATURES = subjects.length;
      const NUM_FEATURES = NUM_INTEREST_FEATURES + NUM_SUBJECT_FEATURES;
      
      // Prepare training data
      const trainingData = [];
      const outputLabels = [];
      const careerLabels = [];
      const employmentRates = {};
      
      // Process each career and create synthetic training examples
      careerDataset.forEach(career => {
        if (!careerLabels.includes(career.career)) {
          careerLabels.push(career.career);
        }
        
        // Store employment rate
        employmentRates[career.career] = parseInt(career.estimated_employment_rate || "50");
        
        // Create multiple training examples for each career
        for (let i = 0; i < 5; i++) { // Generate 5 examples per career for better training
          const featureVector = Array(NUM_FEATURES).fill(0);
          
          // Set interest features (simulated responses)
          // In a real scenario, these would be actual student responses
          const questionId = parseInt(career.question_id);
          if (questionId > 0 && questionId <= NUM_INTEREST_FEATURES) {
            featureVector[questionId - 1] = 1; // Mark this interest as positive
          }
          
          // Set subject features based on required subjects
          if (career.required_subjects) {
            const requiredSubjects = career.required_subjects.split(',').map(s => s.trim());
            requiredSubjects.forEach(subject => {
              const subjectIndex = subjects.indexOf(subject);
              if (subjectIndex !== -1) {
                featureVector[NUM_INTEREST_FEATURES + subjectIndex] = 1;
              }
            });
          }
          
          trainingData.push(featureVector);
          outputLabels.push(careerLabels.indexOf(career.career));
        }
      });
      
      // Create and train TensorFlow model
      // Convert training data to tensors
      const xs = tf.tensor2d(trainingData);
      const ys = tf.oneHot(tf.tensor1d(outputLabels, 'int32'), careerLabels.length);
      
      // Define model architecture
      const model = tf.sequential();
      model.add(tf.layers.dense({
        units: 64,
        activation: 'relu',
        inputShape: [NUM_FEATURES]
      }));
      model.add(tf.layers.dropout(0.2));
      model.add(tf.layers.dense({
        units: 32,
        activation: 'relu'
      }));
      model.add(tf.layers.dropout(0.2));
      model.add(tf.layers.dense({
        units: careerLabels.length,
        activation: 'softmax'
      }));
      
      // Compile model
      model.compile({
        optimizer: 'adam',
        loss: 'categoricalCrossentropy',
        metrics: ['accuracy']
      });
      
      // Train model
      await model.fit(xs, ys, {
        epochs: 50,
        batchSize: 32,
        validationSplit: 0.2,
        callbacks: {
          onEpochEnd: (epoch, logs) => {
            setTrainingProgress(Math.round((epoch + 1) / 50 * 100));
          }
        }
      });
      
      // Save model and related data
      setModel({
        tfModel: model,
        careerLabels: careerLabels,
        subjects: subjects,
        numInterestFeatures: NUM_INTEREST_FEATURES,
        employmentRates: employmentRates
      });
      
      setIsModelTrained(true);
      setTrainingProgress(100);
      
    } catch (error) {
      console.error("Error training model:", error);
    }
  };

  // Make career predictions based on user input
  const predictCareers = () => {
    if (!model) return;
    
    try {
      // Create feature vector from user inputs
      const featureVector = Array(model.numInterestFeatures + model.subjects.length).fill(0);
      
      // Set interest features
      Object.entries(interestAnswers).forEach(([questionId, answer]) => {
        if (answer === 'yes') {
          featureVector[parseInt(questionId) - 1] = 1;
        }
      });
      
      // Set subject features
      selectedSubjects.forEach(subject => {
        const subjectIndex = model.subjects.indexOf(subject);
        if (subjectIndex !== -1) {
          featureVector[model.numInterestFeatures + subjectIndex] = 1;
        }
      });
      
      // Make prediction
      const input = tf.tensor2d([featureVector]);
      const prediction = model.tfModel.predict(input);
      const predictionData = prediction.dataSync();
      
      // Get top 5 career recommendations
      const predictionArray = Array.from(predictionData);
      const topIndices = getTopKIndices(predictionArray, 5);
      
      // Format recommendations with employment rates
      const recommendations = topIndices.map(index => {
        const career = model.careerLabels[index];
        const confidence = predictionArray[index] * 100;
        const employmentRate = model.employmentRates[career] || 50;
        
        return {
          career: career,
          confidence: confidence.toFixed(1),
          employmentRate: employmentRate
        };
      });
      
      setRecommendedCareers(recommendations);
      setCurrentStep(3);
      
    } catch (error) {
      console.error("Error making prediction:", error);
    }
  };

  // Helper function to get top K indices from an array
  const getTopKIndices = (arr, k) => {
    return Array.from(arr.keys())
      .sort((a, b) => arr[b] - arr[a])
      .slice(0, k);
  };

  // Handle yes/no answers to interest questions
  const handleInterestAnswer = (questionId, answer) => {
    setInterestAnswers(prev => ({
      ...prev,
      [questionId]: answer
    }));
  };

  // Handle subject selection
  const handleSubjectToggle = (subject) => {
    setSelectedSubjects(prev => {
      if (prev.includes(subject)) {
        return prev.filter(s => s !== subject);
      } else {
        return [...prev, subject];
      }
    });
  };

  // Handle navigation between steps
  const handleNext = () => {
    if (currentStep === 1 && Object.keys(interestAnswers).length < interestQuestions.length) {
      alert("Please answer all interest questions before proceeding.");
      return;
    }
    
    if (currentStep === 2 && selectedSubjects.length < 3) {
      alert("Please select at least 3 subjects before proceeding.");
      return;
    }
    
    if (currentStep === 2) {
      predictCareers();
    } else {
      setCurrentStep(prev => prev + 1);
    }
  };

  const handleBack = () => {
    setCurrentStep(prev => prev - 1);
  };

  const handleReset = () => {
    setInterestAnswers({});
    setSelectedSubjects([]);
    setRecommendedCareers([]);
    setCurrentStep(0);
  };

  // Render loading screen
  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-gray-50 px-4">
        <div className="text-center">
          <h1 className="text-3xl font-bold mb-2">Career Recommendation AI</h1>
          <p className="text-gray-600 mb-8">Loading and training the model...</p>
          
          <div className="w-full max-w-md mb-4 bg-gray-200 rounded-full h-4">
            <div 
              className="bg-blue-600 h-4 rounded-full transition-all duration-300" 
              style={{ width: `${trainingProgress}%` }}
            ></div>
          </div>
          
          <div className="flex items-center justify-center">
            <Loader2 className="animate-spin mr-2" />
            <span>{trainingProgress}% complete</span>
          </div>
        </div>
      </div>
    );
  }

  // Render welcome screen
  if (currentStep === 0) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-gray-50 px-4">
        <div className="max-w-md w-full bg-white rounded-lg shadow-lg p-8">
          <h1 className="text-3xl font-bold mb-2 text-center">Career Recommendation AI</h1>
          <p className="text-gray-600 mb-6 text-center">Discover careers that match your interests and academic strengths</p>
          
          <div className="space-y-6 mb-8">
            <div className="flex items-start">
              <div className="bg-blue-100 p-2 rounded-full mr-4">
                <BookOpen size={24} className="text-blue-600" />
              </div>
              <div>
                <h3 className="font-semibold text-lg">Interest Assessment</h3>
                <p className="text-gray-600 text-sm">Answer 30 yes/no questions about your interests</p>
              </div>
            </div>
            
            <div className="flex items-start">
              <div className="bg-green-100 p-2 rounded-full mr-4">
                <Award size={24} className="text-green-600" />
              </div>
              <div>
                <h3 className="font-semibold text-lg">Subject Selection</h3>
                <p className="text-gray-600 text-sm">Choose your GCE A-Level subjects</p>
              </div>
            </div>
            
            <div className="flex items-start">
              <div className="bg-purple-100 p-2 rounded-full mr-4">
                <Briefcase size={24} className="text-purple-600" />
              </div>
              <div>
                <h3 className="font-semibold text-lg">Career Matches</h3>
                <p className="text-gray-600 text-sm">Get personalized career recommendations</p>
              </div>
            </div>
            
            <div className="flex items-start">
              <div className="bg-amber-100 p-2 rounded-full mr-4">
                <TrendingUp size={24} className="text-amber-600" />
              </div>
              <div>
                <h3 className="font-semibold text-lg">Employment Outlook</h3>
                <p className="text-gray-600 text-sm">See employment rates for recommended careers</p>
              </div>
            </div>
          </div>
          
          <button 
            onClick={handleNext}
            className="w-full py-3 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 transition-colors"
          >
            Get Started
          </button>
        </div>
      </div>
    );
  }

  // Render interest questions
  if (currentStep === 1) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-gray-50 px-4 py-8">
        <div className="max-w-2xl w-full bg-white rounded-lg shadow-lg p-8">
          <h2 className="text-2xl font-bold mb-6">Interest Assessment</h2>
          <p className="text-gray-600 mb-6">Answer the following questions about your interests to help us recommend suitable careers.</p>
          
          <div className="space-y-6 mb-8">
            {interestQuestions.map((q) => (
              <div key={q.id} className="border-b pb-4">
                <p className="font-medium mb-3">{q.question}</p>
                <div className="flex gap-4">
                  <button
                    onClick={() => handleInterestAnswer(q.id, 'yes')}
                    className={`flex-1 py-2 px-4 rounded-lg border ${
                      interestAnswers[q.id] === 'yes' 
                        ? 'bg-green-100 border-green-500 text-green-700' 
                        : 'border-gray-300 hover:bg-gray-50'
                    }`}
                  >
                    <div className="flex items-center justify-center">
                      {interestAnswers[q.id] === 'yes' && <CheckCircle size={18} className="mr-2" />}
                      Yes
                    </div>
                  </button>
                  <button
                    onClick={() => handleInterestAnswer(q.id, 'no')}
                    className={`flex-1 py-2 px-4 rounded-lg border ${
                      interestAnswers[q.id] === 'no' 
                        ? 'bg-red-100 border-red-500 text-red-700' 
                        : 'border-gray-300 hover:bg-gray-50'
                    }`}
                  >
                    <div className="flex items-center justify-center">
                      {interestAnswers[q.id] === 'no' && <XCircle size={18} className="mr-2" />}
                      No
                    </div>
                  </button>
                </div>
              </div>
            ))}
          </div>
          
          <div className="flex justify-between">
            <button 
              onClick={handleBack}
              className="py-2 px-6 bg-gray-200 text-gray-800 font-medium rounded-lg hover:bg-gray-300 transition-colors"
            >
              Back
            </button>
            <button 
              onClick={handleNext}
              className="py-2 px-6 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 transition-colors"
            >
              Next: Select Subjects
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Render subject selection
  if (currentStep === 2) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-gray-50 px-4 py-8">
        <div className="max-w-3xl w-full bg-white rounded-lg shadow-lg p-8">
          <h2 className="text-2xl font-bold mb-6">Subject Selection</h2>
          <p className="text-gray-600 mb-6">Select the subjects you are studying or interested in studying at the GCE A-Level. Select at least 3 subjects.</p>
          
          <div className="mb-4 text-sm text-blue-600 font-medium">
            Selected: {selectedSubjects.length} subjects
          </div>
          
          {Object.entries(allSubjects).map(([category, subjects]) => (
            <div key={category} className="mb-8">
              <h3 className="font-semibold text-lg mb-3">{category}</h3>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {subjects.map(subject => (
                  <button
                    key={subject}
                    onClick={() => handleSubjectToggle(subject)}
                    className={`py-2 px-4 rounded-lg border text-left ${
                      selectedSubjects.includes(subject)
                        ? 'bg-blue-100 border-blue-500 text-blue-700' 
                        : 'border-gray-300 hover:bg-gray-50'
                    }`}
                  >
                    <div className="flex items-center">
                      {selectedSubjects.includes(subject) ? (
                        <CheckCircle size={16} className="mr-2 flex-shrink-0" />
                      ) : (
                        <div className="w-4 h-4 border border-gray-400 rounded mr-2 flex-shrink-0"></div>
                      )}
                      <span>{subject}</span>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          ))}
          
          <div className="flex justify-between">
            <button 
              onClick={handleBack}
              className="py-2 px-6 bg-gray-200 text-gray-800 font-medium rounded-lg hover:bg-gray-300 transition-colors"
            >
              Back
            </button>
            <button 
              onClick={handleNext}
              disabled={selectedSubjects.length < 3}
              className={`py-2 px-6 font-medium rounded-lg ${
                selectedSubjects.length >= 3
                  ? 'bg-blue-600 text-white hover:bg-blue-700'
                  : 'bg-gray-300 text-gray-500 cursor-not-allowed'
              } transition-colors`}
            >
              Get Career Recommendations
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Render results
  if (currentStep === 3) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-gray-50 px-4 py-8">
        <div className="max-w-3xl w-full bg-white rounded-lg shadow-lg p-8">
          <h2 className="text-2xl font-bold mb-6">Your Career Recommendations</h2>
          <p className="text-gray-600 mb-8">Based on your interests and subjects, here are the top career matches for you.</p>
          
          <div className="mb-8">
            <h3 className="font-semibold text-lg mb-4">Career Matches with Employment Rates</h3>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart
                data={recommendedCareers.map(career => ({
                  name: career.career,
                  "Employment Rate": career.employmentRate,
                  "Match Confidence": parseFloat(career.confidence)
                }))}
                margin={{ top: 5, right: 30, left: 20, bottom: 80 }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis 
                  dataKey="name" 
                  angle={-45} 
                  textAnchor="end"
                  height={80}
                  interval={0}
                />
                <YAxis label={{ value: 'Percentage (%)', angle: -90, position: 'insideLeft' }} />
                <Tooltip />
                <Legend />
                <Bar dataKey="Employment Rate" fill="#4f46e5" />
                <Bar dataKey="Match Confidence" fill="#10b981" />
              </BarChart>
            </ResponsiveContainer>
          </div>
          
          <div className="space-y-4 mb-8">
            {recommendedCareers.map((career, index) => (
              <div key={index} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="font-semibold text-lg">{career.career}</h4>
                    <p className="text-sm text-gray-600">Match Confidence: {career.confidence}%</p>
                  </div>
                  <div className={`text-white text-sm font-medium py-1 px-3 rounded-full ${
                    career.employmentRate >= 70 ? 'bg-green-500' : 
                    career.employmentRate >= 50 ? 'bg-amber-500' : 'bg-red-500'
                  }`}>
                    {career.employmentRate}% Employment Rate
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          <div className="flex justify-between">
            <button 
              onClick={handleBack}
              className="py-2 px-6 bg-gray-200 text-gray-800 font-medium rounded-lg hover:bg-gray-300 transition-colors"
            >
              Back
            </button>
            <button 
              onClick={handleReset}
              className="py-2 px-6 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 transition-colors"
            >
              Start Over
            </button>
          </div>
        </div>
      </div>
    );
  }
}