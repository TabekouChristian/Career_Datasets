# test_model.py
import joblib
import pandas as pd
import numpy as np

def load_model_artifacts():
    """Load the trained model and encoders"""
    model = joblib.load('career_recommender_model.pkl')
    mlb = joblib.load('subject_encoder.pkl')
    return model, mlb

def prepare_input_features(interest_responses, student_subjects, mlb):
    """Prepare input features that exactly match training data format"""
    # Get the original feature names from the model
    try:
        original_features = model.feature_names_in_
    except AttributeError:
        # For older scikit-learn versions
        original_features = None
    
    # Initialize all features to 0
    if original_features is not None:
        features = pd.DataFrame(0, index=[0], columns=original_features)
    else:
        # Fallback - create all possible features
        cameroon_subjects = [
            'english', 'french', 'general paper', 'religious studies', 'philosophy', 'logic',
            'mathematics', 'further mathematics', 'physics', 'chemistry', 'biology', 'computer science',
            'ict', 'geology', 'technical drawing', 'food science', 'nutrition', 'agricultural science',
            'physical education', 'environmental management',
            'history', 'geography', 'literature', 'education', 'art', 'music',
            'economics', 'accounting', 'business mathematics', 'management', 'law', 'commerce'
        ]
        question_features = [f'q_{i}' for i in range(1, 31)]
        sectors = [
            'Business', 'Creative Arts', 'Education', 'Engineering', 'Finance',
            'Healthcare', 'Legal', 'Media', 'Public Service', 'Science',
            'Social Services', 'Technology', 'Technical Trades', 'Tourism', 'Transport'
        ]
        features = pd.DataFrame(0, index=[0], columns=cameroon_subjects + question_features + sectors + ['employment_rate'])

    # Set subject features
    for subject in student_subjects:
        subject = subject.strip().lower()
        if subject in features.columns:
            features[subject] = 1
    
    # Set interest question features
    for q, response in interest_responses.items():
        feature_name = f'q_{q}'
        if feature_name in features.columns:
            features[feature_name] = response
    
    return features

def get_recommendations(model, input_features, top_n=5):
    """Get career recommendations from model"""
    try:
        # Get prediction probabilities
        probas = model.predict_proba(input_features)[0]
        careers = model.classes_
        
        # Create recommendations DataFrame
        recommendations = pd.DataFrame({
            'career': careers,
            'match_score': probas
        }).sort_values('match_score', ascending=False).head(top_n)
        
        return recommendations
    except Exception as e:
        print(f"Error generating recommendations: {str(e)}")
        print("Input features:", input_features.columns.tolist())
        if hasattr(model, 'feature_names_in_'):
            print("Model expects:", model.feature_names_in_.tolist())
        return pd.DataFrame()

if __name__ == '__main__':
    try:
        print("Loading model artifacts...")
        model, mlb = load_model_artifacts()
        
        # Example student data
        # Student with strong arts/humanities background
        # Student with business/commerce focus
        # Student with science/medical aspirations
        interest_responses = {
    1: 1, 2: 1, 3: 0, 4: 0, 5: 0, 6: 0, 7: 0, 8: 0, 9: 0, 10: 0,
    11: 0, 12: 0, 13: 0, 14: 1, 15: 0, 16: 0, 17: 0, 18: 1, 19: 0, 20: 0,
    21: 1, 22: 0, 23: 0, 24: 1, 25: 0, 26: 1, 27: 0, 28: 0, 29: 0, 30: 0
}

        student_subjects = [
    'Biology',
    'Chemistry',
    'Physics',
    'Mathematics',
    'Computer Science'
]



        
        # Prepare features
        print("Preparing input features...")
        input_features = prepare_input_features(interest_responses, student_subjects, mlb)
        
        # Verify feature alignment
        if hasattr(model, 'feature_names_in_'):
            missing_features = set(model.feature_names_in_) - set(input_features.columns)
            extra_features = set(input_features.columns) - set(model.feature_names_in_)
            
            if missing_features:
                print(f"Warning: Missing {len(missing_features)} features the model expects")
            if extra_features:
                print(f"Warning: {len(extra_features)} extra features not used by model")
        
        # Get recommendations
        print("Generating recommendations...")
        recommendations = get_recommendations(model, input_features)
        
        # Display results
        if not recommendations.empty:
            print("\nTop Career Recommendations:")
            print(recommendations[['career', 'match_score']])
        else:
            print("No recommendations could be generated")
            
    except Exception as e:
        print(f"Error: {str(e)}")