import pandas as pd
import numpy as np
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import MultiLabelBinarizer
import joblib
import ast

def load_and_preprocess_data():
    print("Loading and preprocessing data...")
    try:
        # Load datasets
        umbrella_df = pd.read_csv('umbrella_interest_questions_mapping.csv')
        employment_df = pd.read_csv('career_employment_rates.csv')
        subject_df = pd.read_csv('career_subject_requirements.csv')
        
        # Standardize career names
        employment_df = employment_df.rename(columns={'career_name': 'career'})
        for df in [umbrella_df, employment_df, subject_df]:
            df['career'] = df['career'].str.strip().str.lower()
        
        # Process career options
        umbrella_df['career_options'] = umbrella_df['career_options'].apply(ast.literal_eval)
        
        # Merge datasets
        merged_df = pd.merge(subject_df, employment_df, on='career', how='left')
        
        # Cameroon subjects list
        cameroon_subjects = [
            'english', 'french', 'general paper', 'religious studies', 'philosophy', 'logic',
            'mathematics', 'further mathematics', 'physics', 'chemistry', 'biology', 'computer science',
            'ict', 'geology', 'technical drawing', 'food science', 'nutrition', 'agricultural science',
            'physical education', 'environmental management',
            'history', 'geography', 'literature', 'education', 'art', 'music',
            'economics', 'accounting', 'business mathematics', 'management', 'law', 'commerce'
        ]
        
        # Process subject requirements
        merged_df['required_subjects'] = merged_df['required_subjects'].str.lower()
        mlb = MultiLabelBinarizer()
        subject_features = pd.DataFrame(
            mlb.fit_transform(merged_df['required_subjects'].str.split(', ')),
            columns=[col.strip() for col in mlb.classes_],
            index=merged_df.index
        )
        
        # Add missing subjects
        for subject in cameroon_subjects:
            if subject not in subject_features.columns:
                subject_features[subject] = 0
        
        # Process interest questions
        exploded_df = umbrella_df.explode('career_options')
        exploded_df['career_options'] = exploded_df['career_options'].str.strip().str.lower()
        
        career_to_questions = exploded_df.groupby('career_options')['question_id'].apply(set).to_dict()
        
        question_features = pd.DataFrame(0, index=merged_df.index, columns=[f'q_{i}' for i in range(1, 31)])
        for career, questions in career_to_questions.items():
            if career in merged_df['career'].values:
                idx = merged_df[merged_df['career'] == career].index[0]
                for q in questions:
                    question_features.loc[idx, f'q_{q}'] = 1
        
        # Combine features
        X = pd.concat([
            subject_features,
            question_features,
            pd.get_dummies(merged_df['sector'].fillna('Other'))
        ], axis=1)
        
        # Add employment rate
        X['employment_rate'] = merged_df['estimated_employment_rate'].fillna(0)
        
        # Target variable
        y = merged_df['career']
        
        return X, y, mlb
    
    except Exception as e:
        print(f"Error in preprocessing: {str(e)}")
        raise

def train_model(X, y):
    print("Training model with cross-validation...")
    model = GradientBoostingClassifier(
        n_estimators=200,
        learning_rate=0.1,
        max_depth=5,
        random_state=42,
        subsample=0.8
    )
    
    # Cross-validation
    scores = cross_val_score(model, X, y, cv=5, scoring='accuracy')
    print(f"Cross-validation accuracy: {np.mean(scores):.2f} (+/- {np.std(scores):.2f})")
    
    # Final training
    model.fit(X, y)
    return model

if __name__ == '__main__':
    try:
        X, y, mlb = load_and_preprocess_data()
        model = train_model(X, y)
        
        # Save artifacts
        joblib.dump(model, 'career_recommender_model.pkl')
        joblib.dump(mlb, 'subject_encoder.pkl')
        print("Model training completed successfully!")
    
    except Exception as e:
        print(f"Training failed: {str(e)}")