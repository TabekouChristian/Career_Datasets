# core_logic.py
import pandas as pd
from typing import List, Tuple

# Load your datasets
career_dataset = pd.read_csv("final_career_dataset.csv")
career_employment = pd.read_csv("career_employment_rates.csv")
interest_map = pd.read_csv("umbrella_interest_questions_mapping.csv")



def get_interest_matches(selected_interests: List[str]) -> pd.DataFrame:
    """Return careers mapped to at least one of the selected interest questions."""
    matches = interest_map[interest_map['question'].isin(selected_interests)]
    careers = set(matches['career'].tolist())
    return career_dataset[career_dataset['career'].isin(careers)]


def has_required_subjects(student_subjects: List[str], required_subjects: str) -> bool:
    if pd.isna(required_subjects):
        return True
    required = [s.strip() for s in required_subjects.split(',')]
    return all(req in student_subjects for req in required)


def academic_filter(careers: pd.DataFrame, student_subjects: List[str]) -> pd.DataFrame:
    """Keep only careers for which the student has the required subjects."""
    return careers[careers.apply(lambda row: has_required_subjects(student_subjects, row['required_subjects']), axis=1)]


def append_teaching_options(student_subjects: List[str]) -> pd.DataFrame:
    """Return a DataFrame of teaching-related careers based on subjects studied."""
    teaching_careers = []
    for subject in student_subjects:
        teaching_careers.append({
            "career": f"Teacher - {subject}",
            "required_subjects": subject,
            "sector": "Education",
            "salary_range": "120000 - 200000 XAF",
            "description": f"Teach {subject} in secondary/high schools",
            "employment_rate": 75.0
        })
    return pd.DataFrame(teaching_careers)


def enrich_with_employment(careers: pd.DataFrame) -> pd.DataFrame:
    merged = careers.merge(career_employment, on="career", how="left")
    if 'employment_rate_y' in merged.columns:
        merged['employment_rate'] = merged['employment_rate_y'].fillna(merged['employment_rate_x'])
        merged = merged.drop(columns=['employment_rate_x', 'employment_rate_y'])
    return merged


def recommend_careers(selected_interests: List[str], student_subjects: List[str], wants_to_teach: bool) -> Tuple[pd.DataFrame, str]:
    # 1. Filter by interests
    interest_careers = get_interest_matches(selected_interests)

    # 2. Filter by academic background
    matched_careers = academic_filter(interest_careers, student_subjects)

    # 3. Handle teaching option
    if wants_to_teach:
        teaching_options = append_teaching_options(student_subjects)
        matched_careers = pd.concat([matched_careers, teaching_options], ignore_index=True)

    # 4. Enrich with employment data
    final_careers = enrich_with_employment(matched_careers)

    # 5. Handle fallback if no results
    if final_careers.empty:
        return final_careers, "No career matches found. Try adjusting your subject selection or interests."

    return final_careers.sort_values(by="employment_rate", ascending=False), ""

# Example usage:
# selected_questions = ["I love solving technical problems", "I want to help others"]
# subjects = ["Mathematics", "Physics", "Computer Science"]
# result_df, message = recommend_careers(selected_questions, subjects, wants_to_teach=True)
# core_logic.py
import pandas as pd
from typing import List, Tuple

# Load your datasets
career_dataset = pd.read_csv("final_career_dataset.csv")
career_employment = pd.read_csv("career_employment_rates.csv")
interest_map = pd.read_csv("umbrella_interest_questions_mapping.csv")



def get_interest_matches(selected_interests: List[str]) -> pd.DataFrame:
    """Return careers mapped to at least one of the selected interest questions."""
    matches = interest_map[interest_map['question'].isin(selected_interests)]
    careers = set(matches['career'].tolist())
    return career_dataset[career_dataset['career'].isin(careers)]


def has_required_subjects(student_subjects: List[str], required_subjects: str) -> bool:
    if pd.isna(required_subjects):
        return True
    required = [s.strip() for s in required_subjects.split(',')]
    return all(req in student_subjects for req in required)


def academic_filter(careers: pd.DataFrame, student_subjects: List[str]) -> pd.DataFrame:
    """Keep only careers for which the student has the required subjects."""
    return careers[careers.apply(lambda row: has_required_subjects(student_subjects, row['required_subjects']), axis=1)]


def append_teaching_options(student_subjects: List[str]) -> pd.DataFrame:
    """Return a DataFrame of teaching-related careers based on subjects studied."""
    teaching_careers = []
    for subject in student_subjects:
        teaching_careers.append({
            "career": f"Teacher - {subject}",
            "required_subjects": subject,
            "sector": "Education",
            "salary_range": "120000 - 200000 XAF",
            "description": f"Teach {subject} in secondary/high schools",
            "employment_rate": 75.0
        })
    return pd.DataFrame(teaching_careers)


def enrich_with_employment(careers: pd.DataFrame) -> pd.DataFrame:
    merged = careers.merge(career_employment, on="career", how="left")
    if 'employment_rate_y' in merged.columns:
        merged['employment_rate'] = merged['employment_rate_y'].fillna(merged['employment_rate_x'])
        merged = merged.drop(columns=['employment_rate_x', 'employment_rate_y'])
    return merged


def recommend_careers(selected_interests: List[str], student_subjects: List[str], wants_to_teach: bool) -> Tuple[pd.DataFrame, str]:
    # 1. Filter by interests
    interest_careers = get_interest_matches(selected_interests)

    # 2. Filter by academic background
    matched_careers = academic_filter(interest_careers, student_subjects)

    # 3. Handle teaching option
    if wants_to_teach:
        teaching_options = append_teaching_options(student_subjects)
        matched_careers = pd.concat([matched_careers, teaching_options], ignore_index=True)

    # 4. Enrich with employment data
    final_careers = enrich_with_employment(matched_careers)

    # 5. Handle fallback if no results
    if final_careers.empty:
        return final_careers, "No career matches found. Try adjusting your subject selection or interests."

    return final_careers.sort_values(by="employment_rate", ascending=False), ""

# Example usage:
# selected_questions = ["I love solving technical problems", "I want to help others"]
# subjects = ["Mathematics", "Physics", "Computer Science"]
# result_df, message = recommend_careers(selected_questions, subjects, wants_to_teach=True)
