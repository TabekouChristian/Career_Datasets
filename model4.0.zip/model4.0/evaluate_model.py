import joblib
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import classification_report, confusion_matrix

def evaluate():
    try:
        # Load model and data
        model = joblib.load('career_recommender_model.pkl')
        X, y, _ = load_and_preprocess_data()  # Reuse function from train.py
        
        # Split data
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        
        # Evaluate
        y_pred = model.predict(X_test)
        
        print("Classification Report:")
        print(classification_report(y_test, y_pred))
        
        # Confusion matrix
        plt.figure(figsize=(15, 12))
        cm = confusion_matrix(y_test, y_pred)
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues')
        plt.title('Career Recommendation Confusion Matrix')
        plt.ylabel('Actual')
        plt.xlabel('Predicted')
        plt.savefig('confusion_matrix.png')
        print("Confusion matrix saved to confusion_matrix.png")
        
    except Exception as e:
        print(f"Evaluation error: {str(e)}")

if __name__ == '__main__':
    evaluate()