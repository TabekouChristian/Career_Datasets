import pandas as pd

# Load datasets
df = pd.read_csv("final_career_dataset_enhanced.csv")
interest_map_df = pd.read_csv("umbrella_interest_questions_mapping.csv")

# Preview interest questions
print("Sample interest questions:")
print(interest_map_df[['question_id', 'interest_question']].head())

# Step 1: Extract all unique interest questions
interest_questions = interest_map_df['interest_question'].unique().tolist()
print("\n🔢 Total interest questions found:", len(interest_questions))

# Step 2: Ensure every question is a feature in df; if not, add with default 0
for question in interest_questions:
    if question not in df.columns:
        df[question] = 0  # Assume default value for unanswered questions

# Step 3: Academic score as float
df['academic_score'] = pd.to_numeric(df['academic_score'], errors='coerce').fillna(0)

# Step 4: Build X and y
X = df[interest_questions + ['academic_score']]
y = df['career_name']

# Step 5: Save to disk
X.to_csv("X_features.csv", index=False)
y.to_csv("y_labels.csv", index=False)

print("\n✅ Saved X_features.csv and y_labels.csv")
