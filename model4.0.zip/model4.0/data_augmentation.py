import pandas as pd
import numpy as np

def augment_training_data():
    # Load existing data
    df = pd.read_csv('career_subject_requirements.csv')
    
    # Example: Add more arts/humanities careers
    new_arts_careers = [
        {'career': 'art curator', 'required_subjects': 'Art, History, Literature'},
        {'career': 'museum educator', 'required_subjects': 'Education, History, Art'},
        {'career': 'creative writer', 'required_subjects': 'Literature, English, Philosophy'}
    ]
    
    # Example: Add more technical careers 
    new_tech_careers = [
        {'career': 'cloud architect', 'required_subjects': 'Computer Science, Mathematics'},
        {'career': 'data engineer', 'required_subjects': 'Mathematics, Computer Science, Physics'}
    ]
    
    # Combine and save
    augmented_df = pd.concat([
        df,
        pd.DataFrame(new_arts_careers),
        pd.DataFrame(new_tech_careers)
    ], ignore_index=True)
    
    augmented_df.to_csv('augmented_career_data.csv', index=False)
    print(f"Added {len(new_arts_careers)+len(new_tech_careers)} new career records")

if __name__ == '__main__':
    augment_training_data()